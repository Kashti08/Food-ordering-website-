let cart = [];
let total = 0;

function addToCart(item, price) {
  cart.push({ item, price });
  total += price;
  displayCart();
}

function displayCart() {
  const cartList = document.getElementById("cartList");
  cartList.innerHTML = "";
  cart.forEach((c) => {
    let li = document.createElement("li");
    li.innerText = `${c.item} - ₹${c.price}`;
    cartList.appendChild(li);
  });
  document.getElementById("total").innerText = total;
}